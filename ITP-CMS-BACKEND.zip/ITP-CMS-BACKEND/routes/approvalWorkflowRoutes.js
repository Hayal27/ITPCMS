// // approvalworkflowroutes.js

// const express = require('express');
// const router = express.Router();
  
// const {createWorkflow, getWorkflowByPlanId,updateApprovalStatus} = require("../controllers/ApprovalWorkflowController");  // Import the 

// // Route to create an approval workflow
// router.post('/api/approvalworkflow',createWorkflow);  // Use the controller as an object

// // Route to fetch approval workflow by planId
// router.get('/api/approvalworkflow/:planId', getWorkflowByPlanId);  // Use the controller as an object

// // Route to update the approval workflow status
// router.put('/api/approvalworkflow', updateApprovalStatus);  // Use the controller as an object

// module.exports = router;
// /