const express = require("express");
const router = express.Router();
const careerController = require("../controllers/careerController");
const { upload, validateUploadedFile } = require("../middleware/uploadMiddleware");
const { sanitizeInput, validateRequired, validateTypes } = require("../middleware/inputValidation");

const verifyToken = require("../middleware/verifyToken");
const { hasMenuPermission } = require("../middleware/menuPermissionMiddleware");

// Public Routes
router.get("/jobs", careerController.getJobs);

// Apply for job with secure file upload and input validation
router.post(
    "/jobs/apply",
    upload.single("resume"),
    validateUploadedFile,
    sanitizeInput(['coverLetter']), // Allow HTML in cover letter only
    validateRequired(['fullName', 'email', 'phone', 'jobId']),
    validateTypes({ email: 'email', phone: 'phone' }),
    careerController.applyJob
);

router.get("/jobs/track/:code", careerController.trackApplication);

// Admin Routes (Job Management) - Protected by matrix
router.get(
    "/admin/jobs",
    verifyToken,
    hasMenuPermission('/content/careers'),
    careerController.getJobsAdmin
);

router.post(
    "/admin/jobs",
    verifyToken,
    hasMenuPermission('/content/careers'),
    sanitizeInput(['description', 'requirements', 'responsibilities']), // Allow HTML in these fields
    validateRequired(['title', 'department', 'location', 'type', 'deadline']),
    careerController.createJob
);

router.put(
    "/admin/jobs/:id",
    verifyToken,
    hasMenuPermission('/content/careers'),
    sanitizeInput(['description', 'requirements', 'responsibilities']),
    careerController.updateJob
);

router.delete(
    "/admin/jobs/:id",
    verifyToken,
    hasMenuPermission('/content/careers'),
    careerController.deleteJob
);

// Admin Routes (Application Management) - Protected by matrix
router.get(
    "/admin/applications",
    verifyToken,
    hasMenuPermission('/content/careers'),
    careerController.getApplicationsAdmin
);

router.put(
    "/admin/applications/:id/status",
    verifyToken,
    hasMenuPermission('/content/careers'),
    sanitizeInput(['adminNotes', 'appointmentDetails']),
    careerController.updateStatus
);

router.post(
    "/admin/applications/bulk-status",
    verifyToken,
    hasMenuPermission('/content/careers'),
    sanitizeInput(['adminNotes', 'appointmentDetails']),
    careerController.bulkUpdateStatus
);

// Public status check
router.post(
    "/public/application-status",
    sanitizeInput([]),
    validateRequired(['trackingCode']),
    careerController.checkApplicationStatus
);

module.exports = router;
