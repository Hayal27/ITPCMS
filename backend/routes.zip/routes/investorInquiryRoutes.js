const express = require('express');
const router = express.Router();
const investorInquiryController = require('../controllers/investorInquiryController');
const verifyToken = require('../middleware/verifyToken');
const { restrictTo } = require('../middleware/roleMiddleware');

// Public route to submit inquiry
router.post('/submit', investorInquiryController.submitInquiry);

// Admin routes (Protected by matrix)
const { hasMenuPermission } = require('../middleware/menuPermissionMiddleware');

router.get('/admin/inquiries', verifyToken, hasMenuPermission('/interaction/investor-inquiries'), investorInquiryController.getAllInquiries);

module.exports = router;
