const express = require('express');
const router = express.Router();
const verifyToken = require('../middleware/verifyToken');
const { restrictTo } = require('../middleware/roleMiddleware');
const {
    getAllIdCardPersons,
    addIdCardPerson,
    batchAddIdCardPersons,
    updateIdCardPerson,
    deleteIdCardPerson,
    getAllIdTemplates,
    saveIdTemplate,
    updateIdTemplate,
    getPublicIdCardPerson
} = require('../controllers/idCardPersonController');
const { uploadPhoto, handlePhotoUpload } = require('../controllers/imageUploadController');

// All routes protected by token verification and Admin restriction
router.get('/all', verifyToken, restrictTo(1), getAllIdCardPersons);
router.post('/add', verifyToken, restrictTo(1), addIdCardPerson);
router.post('/batch', verifyToken, restrictTo(1), batchAddIdCardPersons);
router.post('/upload-photo', verifyToken, restrictTo(1), uploadPhoto, handlePhotoUpload);
router.get('/templates', verifyToken, restrictTo(1), getAllIdTemplates);
router.post('/templates', verifyToken, restrictTo(1), saveIdTemplate);
router.put('/templates/:id', verifyToken, restrictTo(1), updateIdTemplate);
router.put('/:id', verifyToken, restrictTo(1), updateIdCardPerson);
router.delete('/:id', verifyToken, restrictTo(1), deleteIdCardPerson);
router.get('/public/:idNumber', getPublicIdCardPerson);

module.exports = router;
