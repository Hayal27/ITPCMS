const express = require('express');
const router = express.Router();
const contactController = require('../controllers/contactController');
const verifyToken = require('../middleware/verifyToken');
const { sanitizeInput, validateRequired, validateTypes } = require('../middleware/inputValidation');
const { hasMenuPermission } = require('../middleware/menuPermissionMiddleware');

// Public route to submit contact form
router.post(
    '/contact',
    sanitizeInput(['message']),
    validateRequired(['name', 'email', 'subject', 'message']),
    validateTypes({ email: 'email' }),
    contactController.submitContactForm
);

// Admin routes (Protected by matrix)
router.get(
    '/admin/messages',
    verifyToken,
    hasMenuPermission('/interaction/contact-messages'),
    contactController.getAllMessages
);

router.put(
    '/admin/messages/:id/read',
    verifyToken,
    hasMenuPermission('/interaction/contact-messages'),
    contactController.markAsRead
);

router.post(
    '/admin/messages/:id/reply',
    verifyToken,
    hasMenuPermission('/interaction/contact-messages'),
    sanitizeInput(['replyMessage']),
    validateRequired(['replyMessage']),
    contactController.replyToMessage
);

router.delete(
    '/admin/messages/:id',
    verifyToken,
    hasMenuPermission('/interaction/contact-messages'),
    contactController.deleteMessage
);

module.exports = router;
