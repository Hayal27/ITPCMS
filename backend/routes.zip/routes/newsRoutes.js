const express = require('express');
const router = express.Router();
const newsController = require('../controllers/newsController');
const verifyToken = require('../middleware/verifyToken');
const { upload, validateUploadedFile } = require('../middleware/uploadMiddleware');
const { sanitizeInput, validateRequired } = require('../middleware/inputValidation');
const { hasMenuPermission } = require('../middleware/menuPermissionMiddleware');

// Public routes for fetching news
router.get('/news', newsController.getAllNews);
router.get('/newsf', newsController.getAllNews); // Frontend alias
router.get('/news/:id', newsController.getNewsById);
router.get('/news/:id/comments', newsController.getCommentsByPostId);
router.get('/newsf/:id/comments', newsController.getCommentsByPostId);

// Post comment with input validation
router.post(
    '/news/:id/comments',
    sanitizeInput([]),
    validateRequired(['content', 'author']),
    newsController.postComment
);

// Protected routes for managing news
router.post(
    '/news',
    verifyToken,
    hasMenuPermission('/post/managePosts'),
    upload.any(),
    validateUploadedFile,
    sanitizeInput(['content', 'excerpt']), // Allow HTML in content and excerpt
    validateRequired(['title', 'content']),
    newsController.createNews
);

router.put(
    '/editNews/:id',
    verifyToken,
    hasMenuPermission('/post/managePosts'),
    upload.any(),
    validateUploadedFile,
    sanitizeInput(['content', 'excerpt']),
    newsController.updateNews
);

router.delete(
    '/deleteNews/:id',
    verifyToken,
    hasMenuPermission('/post/managePosts'),
    newsController.deleteNews
);

module.exports = router;
